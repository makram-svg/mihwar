/**
 * Mihwar (مِحور) — Google Apps Script backend
 * Google Sheets backup/restore + read-only Calendar and Gmail helpers.
 * No Google credentials are stored in the browser.
 */
const MIHWAR_PROP_SHEET_ID = 'MIHWAR_BACKUP_SPREADSHEET_ID';
const MIHWAR_TABS = ['Tasks', 'Projects', 'Plans'];
// true = Google services (Sheets/Calendar/Gmail) answer only the account that deployed the app.
// Keep it true even if you share the link: nobody else can read your mail or calendar through it.
const MIHWAR_OWNER_ONLY = true;

function requireOwner_() {
  if (!MIHWAR_OWNER_ONLY) return;
  const owner = Session.getEffectiveUser().getEmail();
  const viewer = Session.getActiveUser().getEmail();
  if (!owner || !viewer || owner.toLowerCase() !== viewer.toLowerCase()) {
    throw new Error('خدمات Google في هذا التطبيق متاحة لمالكه فقط.');
  }
}

function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('مِحور | Mihwar')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function mihwarConnectionCheck() {
  requireOwner_();
  const ss = getOrCreateBackupSpreadsheet_();
  return { ok: true, spreadsheetId: ss.getId(), spreadsheetUrl: ss.getUrl() };
}

function mihwarBackupToSheets(payload) {
  requireOwner_();
  if (!payload || !Array.isArray(payload.tasks) || !Array.isArray(payload.projects) || !Array.isArray(payload.plans)) {
    throw new Error('صيغة النسخة الاحتياطية غير صالحة.');
  }
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const ss = getOrCreateBackupSpreadsheet_();
    const collections = { Tasks: payload.tasks, Projects: payload.projects, Plans: payload.plans };
    // Build and validate every row first, so a bad record can never leave the backup half-written.
    const built = {};
    Object.keys(collections).forEach(function(tabName) {
      built[tabName] = collections[tabName].map(function(item) {
        const json = JSON.stringify(item);
        if (json.length > 45000) throw new Error('أحد السجلات كبير جداً لحفظه في خلية Google Sheets.');
        return [String(item.id || ''), json, payload.exportedAt || new Date().toISOString()];
      });
    });
    Object.keys(built).forEach(function(tabName) {
      const sh = getOrCreateSheet_(ss, tabName);
      const rows = built[tabName];
      sh.clearContents();
      sh.getRange(1, 1, 1, 3).setValues([['id', 'record_json', 'backup_timestamp']]);
      if (rows.length) sh.getRange(2, 1, rows.length, 3).setValues(rows);
      sh.setFrozenRows(1);
      sh.autoResizeColumns(1, 3);
    });
    const meta = getOrCreateSheet_(ss, 'Backup Info');
    meta.clearContents();
    meta.getRange(1, 1, 4, 2).setValues([
      ['product', 'Mihwar'],
      ['format', payload.format || 'mihwar-backup-v1'],
      ['backup_timestamp', payload.exportedAt || new Date().toISOString()],
      ['note', 'Tasks, projects and plans only. Browser attachments are not included.']
    ]);
    return { ok: true, spreadsheetId: ss.getId(), spreadsheetUrl: ss.getUrl(), savedAt: new Date().toISOString() };
  } finally {
    lock.releaseLock();
  }
}

function mihwarRestoreFromSheets() {
  requireOwner_();
  const ss = getOrCreateBackupSpreadsheet_();
  const result = { format: 'mihwar-backup-v1', exportedAt: '', tasks: [], projects: [], plans: [] };
  const mapping = { Tasks: 'tasks', Projects: 'projects', Plans: 'plans' };
  MIHWAR_TABS.forEach(function(tabName) {
    const sh = ss.getSheetByName(tabName);
    if (!sh || sh.getLastRow() < 2) return;
    const values = sh.getRange(2, 1, sh.getLastRow() - 1, 2).getValues();
    values.forEach(function(row) {
      if (!row[1]) return;
      try { result[mapping[tabName]].push(JSON.parse(row[1])); }
      catch (e) { throw new Error('تعذر قراءة سجل من ورقة ' + tabName + '. لا توجد تغييرات مطبقة على التطبيق.'); }
    });
  });
  const info = ss.getSheetByName('Backup Info');
  if (info && info.getLastRow() >= 3) result.exportedAt = String(info.getRange(3, 2).getValue() || '');
  if (!result.tasks.length && !result.projects.length && !result.plans.length) {
    throw new Error('لا توجد نسخة احتياطية محفوظة في Google Sheets حتى الآن.');
  }
  return result;
}

function mihwarGetUpcomingCalendarEvents() {
  requireOwner_();
  const cal = CalendarApp.getDefaultCalendar();
  const now = new Date();
  const until = new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000);
  return cal.getEvents(now, until, { max: 30 }).map(function(event) {
    return {
      id: event.getId(),
      title: event.getTitle() || '(بدون عنوان)',
      start: Utilities.formatDate(event.getStartTime(), Session.getScriptTimeZone(), 'EEE, dd MMM yyyy · HH:mm'),
      end: Utilities.formatDate(event.getEndTime(), Session.getScriptTimeZone(), 'HH:mm'),
      location: event.getLocation() || ''
    };
  });
}

function mihwarSearchGmail(query) {
  requireOwner_();
  query = String(query || 'newer_than:7d').trim().slice(0, 250);
  // Search is limited to 10 results. The app only receives message metadata and snippets.
  return GmailApp.search(query, 0, 10).map(function(thread) {
    const msg = thread.getMessages().slice(-1)[0];
    return {
      id: msg.getId(),
      subject: msg.getSubject() || '(بدون عنوان)',
      from: msg.getFrom() || '',
      date: Utilities.formatDate(msg.getDate(), Session.getScriptTimeZone(), 'dd MMM yyyy · HH:mm'),
      snippet: (msg.getPlainBody() || '').replace(/\s+/g, ' ').slice(0, 240)
    };
  });
}

function getOrCreateBackupSpreadsheet_() {
  const props = PropertiesService.getScriptProperties();
  const existingId = props.getProperty(MIHWAR_PROP_SHEET_ID);
  if (existingId) {
    try { return SpreadsheetApp.openById(existingId); }
    catch (e) { props.deleteProperty(MIHWAR_PROP_SHEET_ID); }
  }
  const ss = SpreadsheetApp.create('مِحور — النسخ الاحتياطي');
  props.setProperty(MIHWAR_PROP_SHEET_ID, ss.getId());
  const first = ss.getSheets()[0];
  first.setName('Tasks');
  first.getRange(1, 1, 1, 3).setValues([['id', 'record_json', 'backup_timestamp']]);
  ['Projects', 'Plans', 'Backup Info'].forEach(function(name) { ss.insertSheet(name); });
  return ss;
}

function getOrCreateSheet_(ss, name) {
  return ss.getSheetByName(name) || ss.insertSheet(name);
}
